package caixeiroviajante;

import java.util.ArrayList;
import java.util.Random;

public class Algoritmos {
    
    private final float Matriz [][];
    
    public Algoritmos (float Matriz [][]){
        this.Matriz = Matriz;
    }
    
    public void VizinhoMaisProximo() {
        ArrayList<Integer> Solucao = new ArrayList();
        ArrayList<Boolean> Visitado = new ArrayList();
        for (float[] Matriz1 : Matriz) {
            Visitado.add(false);
        }
        
        Solucao.add(0);
        Visitado.set(0, true);
        int i = 0 , index = 0;
        while(Solucao.size() != Matriz.length){
            float aux = 999999999;
            for (int j = 0 ; j < Matriz[i].length ; j++){
                if( i == j || Visitado.get(j) == true){
                    
                }else if(Matriz[i][j] < aux){
                    aux = Matriz[i][j];
                    index = j;
                }
            }
            Solucao.add(index);
            Visitado.set(index, true);
            i = index;
        }
        Solucao.add(0);
        
        System.out.println("\nSolução do algoritmo do vizinho mais próximo\n");
        for(int k = 0; k < Solucao.size(); k++){
            if( k == Solucao.size() - 1){
                System.out.print(Solucao.get(k) + "\n\n");
            }else{
                System.out.print(Solucao.get(k) + " --> ");
            }
            
        }
        CalculaFuncaoObjetiva(Solucao);
    }
    
    public void InsercaoMaisBarata (){
        
    }
    
    public void Aleatorio  (){
        Random Gerador = new Random();
        ArrayList<Integer> Solucao = new ArrayList();
        ArrayList<Boolean> Visitado = new ArrayList();
        for (float[] Matriz1 : Matriz) {
            Visitado.add(false);
        }
        
        Solucao.add(0);
        Visitado.set(0, true);
        int i = 0;
        while(Solucao.size() != Matriz.length){
            int num = Gerador.nextInt(Matriz.length);
            if (!Solucao.contains(num) && Visitado.get(num) == false) {
                Solucao.add(num);
                Visitado.set(num, true);
            }
        }
        Solucao.add(0);
        
        System.out.println("\nSolução do algoritmo com solução aleatória\n");
        for(int k = 0; k < Solucao.size(); k++){
            if( k == Solucao.size() - 1){
                System.out.print(Solucao.get(k) + "\n\n");
            }else{
                System.out.print(Solucao.get(k) + " --> ");
            }
            
        }
        
        CalculaFuncaoObjetiva(Solucao);
    }
    
    public void CalculaFuncaoObjetiva(ArrayList Solucao){
        float Distancia = 0;
        for ( int i = 0; i < Matriz.length; i++ ) {
            Distancia += Matriz[(int)Solucao.get(i)][(int)Solucao.get(i+1)];
        }
         System.out.println("Função Objetiva: " + Distancia + "\n");
    }
}
