package caixeiroviajante;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Algoritmos {

    private final float Matriz[][];

    public Algoritmos(float Matriz[][]) {
        this.Matriz = Matriz;
    }

    public void VizinhoMaisProximo() {
        ArrayList<Integer> Solucao = new ArrayList<Integer>();
        ArrayList<Boolean> Visitado = new ArrayList<Boolean>();
        for (float[] Matriz1 : Matriz) {
            Visitado.add(false);
        }

        Solucao.add(0);
        Visitado.set(0, true);
        int i = 0, index = 0;
        while (Solucao.size() != Matriz.length) {
            float aux = Float.MAX_VALUE;
            for (int j = 0; j < Matriz[i].length; j++) {
                if (i == j || Visitado.get(j) == true) {

                } else if (Matriz[i][j] < aux) {
                    aux = Matriz[i][j];
                    index = j;
                }
            }
            Solucao.add(index);
            Visitado.set(index, true);
            i = index;
        }
        Solucao.add(0);

        System.out.println("\nSolução do algoritmo do vizinho mais próximo\n");
        for (int k = 0; k < Solucao.size(); k++) {
            if (k == Solucao.size() - 1) {
                System.out.print(Solucao.get(k) + "\n\n");
            } else {
                System.out.print(Solucao.get(k) + " --> ");
            }

        }
        CalculaFuncaoObjetiva(Solucao);
    }
    
    public void ParcialmenteVizinhoMaisProximo(float Alpha){
        Random Gerador = new Random();
        ArrayList<Integer> Solucao = new ArrayList<Integer>();
        ArrayList<Boolean> Visitado = new ArrayList<Boolean>();
        ArrayList<Integer> Auxiliar = new ArrayList<Integer>();
        for (float[] Matriz1 : Matriz) {
            Visitado.add(false);
        }

        Solucao.add(0);
        Visitado.set(0, true);
        
        int i = 0, index = 0;
        while (Solucao.size() != Matriz.length) {
            int TamanhoLRC = Math.round(1 + (Alpha * ((Matriz.length - Solucao.size()) - 1)));
            for(int k = 0; k < TamanhoLRC; k++){
                float aux = Float.MAX_VALUE;
                for (int j = 0; j < Matriz[i].length; j++) {
                    if (i == j || Visitado.get(j) == true || Auxiliar.contains(j)) {

                    } else if (Matriz[i][j] < aux) {
                        aux = Matriz[i][j];
                        index = j;
                    }
                }
                Auxiliar.add(index);
            }
            int cidade_escolhida = Gerador.nextInt(Auxiliar.size());
            
            Solucao.add(Auxiliar.get(cidade_escolhida));
            Visitado.set(Auxiliar.get(cidade_escolhida), true);
            i = Auxiliar.get(cidade_escolhida);
            Auxiliar.clear();
        }
        Solucao.add(0);

        System.out.println("\nSolução do algoritmo do vizinho mais próximo\n");
        for (int k = 0; k < Solucao.size(); k++) {
            if (k == Solucao.size() - 1) {
                System.out.print(Solucao.get(k) + "\n\n");
            } else {
                System.out.print(Solucao.get(k) + " --> ");
            }

        }
        CalculaFuncaoObjetiva(Solucao);
    }

    public void InsercaoMaisBarata() {
        Random Gerador = new Random();
        ArrayList<Integer> Solucao = new ArrayList();

        // Gera solu��o inicial aleatoria
        for (int i = 0; i < 3; i++) {
            int num = Gerador.nextInt(Matriz.length);
            if (!Solucao.contains(num)) {
                Solucao.add(num);
            }
        }
        Solucao.add(Solucao.get(0));

        // calcula solu��o
        while (Solucao.size() != Matriz.length + 1) {

            int cidadeMaisBarata = -1;
            int arestaParaInsercao = -1;
            float insercaoMaisBarata = Float.MAX_VALUE;

            //percorre todas as cidades
            for (int cidadeAtual = 0; cidadeAtual < Matriz.length; cidadeAtual++) {
                // se a posi��o atual n�o esta na solu��o verifica a sua inser��o
                if (!Solucao.contains(cidadeAtual)) {
                    // Verifica as arestas
                    for (int aux = 0; aux < Solucao.size() - 1; aux++) {
                        // compara valor da inser��o na aresta
                        if ((Matriz[Solucao.get(aux)][cidadeAtual]
                                + Matriz[cidadeAtual][Solucao.get(aux + 1)]) < insercaoMaisBarata) {
                            // se a insercao for a mais barata encontrada, armazena seu valor, qual a cidade
                            // e qual a posi��o
                            insercaoMaisBarata = Matriz[Solucao.get(aux)][cidadeAtual]
                                    + Matriz[cidadeAtual][Solucao.get(aux + 1)];
                            cidadeMaisBarata = cidadeAtual;
                            arestaParaInsercao = aux;
                        }
                    }
                }
            }
            // Insere a cidade no percurso
            Solucao.add(arestaParaInsercao + 1, cidadeMaisBarata);
        }

        // Imprime a solu��o
        System.out.println("\nSolução do algoritmo com inser��o mais barata\n");
        for (int k = 0; k < Solucao.size(); k++) {
            if (k == Solucao.size() - 1) {
                System.out.print(Solucao.get(k) + "\n\n");
            } else {
                System.out.print(Solucao.get(k) + " --> ");
            }

        }

        CalculaFuncaoObjetiva(Solucao);
    }

    public void Aleatorio() {
        Random Gerador = new Random();
        ArrayList<Integer> Solucao = new ArrayList();
        ArrayList<Boolean> Visitado = new ArrayList();
        for (float[] Matriz1 : Matriz) {
            Visitado.add(false);
        }

        Solucao.add(0);
        Visitado.set(0, true);
        int i = 0;
        while (Solucao.size() != Matriz.length) {
            int num = Gerador.nextInt(Matriz.length);
            if (!Solucao.contains(num) && Visitado.get(num) == false) {
                Solucao.add(num);
                Visitado.set(num, true);
            }
        }
        Solucao.add(0);

        System.out.println("\nSolução do algoritmo com solução aleatória\n");
        for (int k = 0; k < Solucao.size(); k++) {
            if (k == Solucao.size() - 1) {
                System.out.print(Solucao.get(k) + "\n\n");
            } else {
                System.out.print(Solucao.get(k) + " --> ");
            }

        }

        CalculaFuncaoObjetiva(Solucao);
    }

    public void CalculaFuncaoObjetiva(ArrayList<Integer> Solucao) {
        float Distancia = 0;
        for (int i = 0; i < Matriz.length - 1; i++) {
            Distancia += Matriz[(int) Solucao.get(i)][(int) Solucao.get(i + 1)];
        }
        System.out.println("Função Objetiva: " + Distancia + "\n");
    }

}
